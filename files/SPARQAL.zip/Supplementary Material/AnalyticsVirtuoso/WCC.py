from SPARQLWrapper import SPARQLWrapper, POST, DIGEST, JSON
from collections import deque

sparql = SPARQLWrapper("http://localhost:8890/sparql/")

sparql.setHTTPAuth(DIGEST)
sparql.setCredentials("dba", "dba")
sparql.setMethod(POST)

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/degree>
""")

results = sparql.query()

offset = 0
values = dict()
wcc = dict()
while True:
  print(offset)
  sparql.setQuery("""
  SELECT * 
  FROM <http://example.org/patentsu>
  WHERE {
    ?x ?y ?z
  } LIMIT 10000 OFFSET """ + str(offset) + """
  """)

  results = sparql.query()
  sparql.setReturnFormat(JSON)
  results = sparql.query().convert()

  count = 0
  for result in results["results"]["bindings"]:
    x = result["x"]["value"]
    z = result["z"]["value"]
    if x in values.keys():
      values[x].add(z)
    else:
      values[x] = set()
      values[x].add(z)
    if z in values.keys():
      values[z].add(x)
    else:
      values[z] = set()
      values[z].add(x)
    if x not in wcc.keys():
      wcc[x] = 0
    if z not in wcc.keys():
      wcc[z] = 0
    count += 1

  if count < 9999:
    break
  offset += 10000

print("Neighbours OK!")

group = 1
for node_key in values.keys():
  stack = deque([node_key])
  if wcc[node_key] == 0:
    wcc[node_key] = group
    while len(stack) > 0:
      current_node = stack.pop()
      for neighbour in values[current_node]:
        if wcc[neighbour] == 0:
          wcc[neighbour] = group
          stack.append(neighbour)
    group += 1


print(offset)
print(wcc)
print("END")
# 2:29.56 total