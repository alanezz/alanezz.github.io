from SPARQLWrapper import SPARQLWrapper, POST, DIGEST, JSON

sparql = SPARQLWrapper("http://localhost:8890/sparql/")

sparql.setHTTPAuth(DIGEST)
sparql.setCredentials("dba", "dba")
sparql.setMethod(POST)

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/triangles>
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/triangles>
INSERT { ?node <http://www.sparqual.org/triangles> ?trcount }
USING <http://example.org/patentsu>
WHERE {
  SELECT ?node (COUNT(*) as ?trcount) WHERE {
    GRAPH <http://example.org/patentsu> { 
      ?node <http://example.org/p> ?node2 .
      ?node <http://example.org/p> ?node3 .
      ?node3 <http://example.org/p> ?node2 .
      FILTER(str(?node2) < str(?node3))
    } . 
  } GROUP BY ?node
}
""")

results = sparql.query()

