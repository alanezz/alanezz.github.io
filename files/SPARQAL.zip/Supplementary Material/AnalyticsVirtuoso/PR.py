from SPARQLWrapper import SPARQLWrapper, POST, DIGEST, JSON

sparql = SPARQLWrapper("http://localhost:8890/sparql/")

sparql.setHTTPAuth(DIGEST)
sparql.setCredentials("dba", "dba")
sparql.setMethod(POST)

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/nodes>
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/global>
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/degree>
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/rank>
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/rankNext>
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/weakRank>
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/nodes>
INSERT { ?node <http://www.sparqual.org/placeholderprop> <http://www.sparqual.org/placeholderobj> }
USING <http://example.org/patents>
WHERE {
  { SELECT ?node WHERE { GRAPH  <http://example.org/patents> { ?node ?y ?z } } } 
  UNION 
  { SELECT ?node WHERE { GRAPH  <http://example.org/patents> { ?x ?y ?node } } }
}
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/global>
INSERT { <http://www.sparqual.org/global> <http://www.sparqual.org/n> ?n }
USING <http://www.sparqual.org/graphs/nodes>
WHERE {
  SELECT (COUNT(*) AS ?n) WHERE {
    GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?y ?z } 
  }
}
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/degree>
INSERT { ?node <http://www.sparqual.org/degree> ?degree }
USING <http://www.sparqual.org/graphs/nodes>
USING <http://example.org/patents>
WHERE {
  SELECT ?node (COUNT(DISTINCT ?o) as ?degree) WHERE {
    GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?y ?z } . 
    OPTIONAL { GRAPH <http://example.org/patents> { ?node ?p ?o } }
  } GROUP BY ?node
}
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/rank>
INSERT { ?node <http://www.sparqual.org/rank> ?rank }
USING <http://www.sparqual.org/graphs/nodes>
USING <http://www.sparqual.org/graphs/global>
WHERE {
  GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?p ?o } .
  GRAPH <http://www.sparqual.org/graphs/global> { <http://www.sparqual.org/global> <http://www.sparqual.org/n> ?n } . 
  BIND (1.0/?n AS ?rank)
}
""")

results = sparql.query()

for i in range(10):
  print(i)
  
  sparql.setQuery("""
  DROP SILENT GRAPH <http://www.sparqual.org/graphs/rankNext>
  """)

  results = sparql.query()

  sparql.setQuery("""
  WITH <http://www.sparqual.org/graphs/rankNext>
  INSERT { ?neighbour <http://www.sparqual.org/rankNext> ?rankNext }
  USING <http://www.sparqual.org/graphs/degree>
  USING <http://www.sparqual.org/graphs/rank>
  USING <http://example.org/patents>
  WHERE {
    SELECT ?neighbour (SUM(?rankEach) AS ?rankNext) WHERE {
      GRAPH <http://www.sparqual.org/graphs/degree> { ?node <http://www.sparqual.org/degree> ?degree FILTER (?degree >0) } . 
      GRAPH <http://www.sparqual.org/graphs/rank> { ?node <http://www.sparqual.org/rank> ?rank } . 
      GRAPH <http://example.org/patents> { ?node ?p ?neighbour } .
      BIND((?rank*0.85)/?degree AS ?rankEach) 
    } GROUP BY ?neighbour
  }
  """)

  results = sparql.query()

  sparql.setQuery("""
  DROP SILENT GRAPH <http://www.sparqual.org/graphs/weakRank>
  """)

  results = sparql.query()

  sparql.setQuery("""
  WITH <http://www.sparqual.org/graphs/weakRank>
  INSERT { <http://www.sparqual.org/global> <http://www.sparqual.org/weakRank> ?weak }
  USING <http://www.sparqual.org/graphs/rankNext>
  USING <http://www.sparqual.org/graphs/global>
  WHERE {
    SELECT ((1-SUM(?rankNext))/?n AS ?weak) WHERE { 
      GRAPH <http://www.sparqual.org/graphs/rankNext> { ?neighbour <http://www.sparqual.org/rankNext> ?rankNext } . 
      GRAPH <http://www.sparqual.org/graphs/global> { <http://www.sparqual.org/global> <http://www.sparqual.org/n> ?n }  .
    } GROUP BY ?n
  }
  """)

  results = sparql.query()

  sparql.setQuery("""
  DROP SILENT GRAPH <http://www.sparqual.org/graphs/rank>
  """)

  results = sparql.query()

  sparql.setQuery("""
  WITH <http://www.sparqual.org/graphs/rank>
  INSERT { ?node <http://www.sparqual.org/rank> ?rankBound }
  USING <http://www.sparqual.org/graphs/nodes>
  USING <http://www.sparqual.org/graphs/rankNext>
  USING <http://www.sparqual.org/graphs/weakRank>
  WHERE {
    GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?p ?o } . 
    OPTIONAL {
      { 
        SELECT ?node ?rankNext WHERE {
          GRAPH <http://www.sparqual.org/graphs/rankNext> { ?node <http://www.sparqual.org/rankNext> ?rankNext }
        }
      }
    }
    GRAPH <http://www.sparqual.org/graphs/weakRank> { <http://www.sparqual.org/global> <http://www.sparqual.org/weakRank> ?weak } . 
    BIND((COALESCE(?rankNext, 0) + ?weak) AS ?rankBound)   
  }
  """)

  results = sparql.query()