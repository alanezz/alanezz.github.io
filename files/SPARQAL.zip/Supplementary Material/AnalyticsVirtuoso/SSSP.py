from SPARQLWrapper import SPARQLWrapper, POST, DIGEST, JSON

sparql = SPARQLWrapper("http://localhost:8890/sparql/")

sparql.setHTTPAuth(DIGEST)
sparql.setCredentials("dba", "dba")
sparql.setMethod(POST)

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/global>
""")

results = sparql.query()


sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/global>
INSERT {
    <http://www.sparqual.org/global> <http://www.sparqual.org/iter> 0 .
}
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/visited>
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/visited>
INSERT {
    <http://example.org/v6009541> <http://www.sparqual.org/depth> 0 . 
    <http://example.org/v6009541> <http://www.sparqual.org/path> \"\"
}
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/visitNew>
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/visitNew>
INSERT {
    <http://example.org/v6009541> <http://www.sparqual.org/depth> 0 . 
    <http://example.org/v6009541> <http://www.sparqual.org/path> \"\"
}
""")

results = sparql.query()

count = 0
while True:
    print(count)
    sparql.setQuery("""
    DROP SILENT GRAPH <http://www.sparqual.org/graphs/visit>
    """)
    results = sparql.query()

    sparql.setQuery("""
    WITH <http://www.sparqual.org/graphs/visit>
    INSERT {
        ?neighbour <http://www.sparqual.org/depth> ?depth2 . 
        ?neighbour <http://www.sparqual.org/path> ?path2
    } 
    USING <http://www.sparqual.org/graphs/global>
    USING <http://www.sparqual.org/graphs/visitNew>
    USING <http://example.org/patents>
    WHERE {
        GRAPH <http://www.sparqual.org/graphs/global> { 
            <http://www.sparqual.org/global> <http://www.sparqual.org/iter> ?depth 
        } . 
        GRAPH <http://www.sparqual.org/graphs/visitNew> { 
            ?node <http://www.sparqual.org/depth> ?depth . 
            ?node <http://www.sparqual.org/path> ?path 
        } . 
        GRAPH <http://example.org/patents> {
            ?node ?p ?neighbour
        } .
        BIND (?depth + 1 AS ?depth2) . BIND ( (CONCAT(?path," -[",STR(?p),"]-> ",STR(?neighbour))) AS ?path2 ) 
    }
    """)

    results = sparql.query()


    sparql.setQuery("""
    DROP SILENT GRAPH <http://www.sparqual.org/graphs/visitNew>
    """)
    results = sparql.query()

    sparql.setQuery("""
    WITH <http://www.sparqual.org/graphs/visitNew>
    INSERT {
        ?node <http://www.sparqual.org/depth> ?depth . 
        ?node <http://www.sparqual.org/path> ?path
    } 
    USING <http://www.sparqual.org/graphs/visit>
    USING <http://www.sparqual.org/graphs/visited>
    WHERE {
        { 
            GRAPH <http://www.sparqual.org/graphs/visit> { 
                ?node <http://www.sparqual.org/depth> ?depth . 
                ?node <http://www.sparqual.org/path> ?path 
            } 
        } MINUS
        { 
            SELECT ?node WHERE { 
                GRAPH <http://www.sparqual.org/graphs/visited> { 
                    ?node <http://www.sparqual.org/depth> ?depth2 
                } 
            } 
        }
    }
    """)

    results = sparql.query()

    sparql.setQuery("""
    WITH <http://www.sparqual.org/graphs/visited>
    INSERT {
        ?s ?p ?o
    } 
    USING <http://www.sparqual.org/graphs/visitNew>
    WHERE {
        GRAPH <http://www.sparqual.org/graphs/visitNew> { 
            ?s ?p ?o
        } 
    }
    """)

    results = sparql.query()

    sparql.setQuery("""
    DROP SILENT GRAPH <http://www.sparqual.org/graphs/global>
    """)

    results = sparql.query()

    sparql.setQuery("""
    WITH <http://www.sparqual.org/graphs/global>
    INSERT {
        <http://www.sparqual.org/global> <http://www.sparqual.org/iter> """ + str(count + 1) + """
    }
    """)

    results = sparql.query()

    sparql.setQuery("""
        SELECT (COUNT(*) AS ?c) 
        FROM <http://www.sparqual.org/graphs/visitNew>
        WHERE {
            ?x ?y ?z
        }
    """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()

    for result in results["results"]["bindings"]:
        c = result["c"]["value"]

    c = int(c)

    if c == 0:
        break
    count += 1