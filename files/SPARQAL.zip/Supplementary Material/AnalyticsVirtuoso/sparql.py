from SPARQLWrapper import SPARQLWrapper, POST, DIGEST, JSON

sparql = SPARQLWrapper("http://localhost:8890/sparql/")

sparql.setHTTPAuth(DIGEST)
sparql.setCredentials("dba", "dba")
sparql.setMethod(POST)

sparql.setQuery("""
WITH <http://example.org/delta>
INSERT {
    <http://example.org/v01> ?y ?z
} 
USING <http://example.org/examplegraph>
WHERE {
    <http://example.org/v01> ?y ?z
}
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://example.org/recursive>
INSERT {
    <http://example.org/v01> ?y ?z
} 
USING <http://example.org/examplegraph>
WHERE {
    GRAPH <http://example.org/examplegraph> {
        <http://example.org/v01> ?y ?z
    }
}
""")

results = sparql.query()

sparql.setQuery("""
    SELECT (COUNT(*) AS ?c) 
    FROM <http://example.org/delta>
    WHERE {
        ?x ?y ?z
    }
""")
sparql.setReturnFormat(JSON)
results = sparql.query().convert()

for result in results["results"]["bindings"]:
    c = result["c"]["value"]

print(int(c))