from SPARQLWrapper import SPARQLWrapper, POST, DIGEST, JSON

sparql = SPARQLWrapper("http://localhost:8890/sparql/")

sparql.setHTTPAuth(DIGEST)
sparql.setCredentials("dba", "dba")
sparql.setMethod(POST)

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/global>
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/depth>
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/depthNext>
""")

results = sparql.query()

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/depthNextNew>
""")

results = sparql.query()


sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/global>
INSERT {
    <http://www.sparqual.org/global> <http://www.sparqual.org/iter> 0 .
}
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/depth>
INSERT {
    <http://example.org/v6009541> <http://www.sparqual.org/depth> 0 .
}
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/depthNextNew>
INSERT {
    <http://example.org/v6009541> <http://www.sparqual.org/depth> 0 .
}
""")

results = sparql.query()

count = 0
while True:

    sparql.setQuery("""
    DROP SILENT GRAPH <http://www.sparqual.org/graphs/depthNext>
    """)
    results = sparql.query()

    sparql.setQuery("""
    WITH <http://www.sparqual.org/graphs/depthNext>
    INSERT {
        ?neighbour <http://www.sparqual.org/depthNext> ?depth2
    } 
    USING <http://www.sparqual.org/graphs/depthNextNew>
    USING <http://example.org/patents>
    WHERE {
        GRAPH <http://www.sparqual.org/graphs/depthNextNew> { 
            ?node <http://www.sparqual.org/depth> ?depth
        } . 
        GRAPH <http://example.org/patents> { 
            ?node ?p ?neighbour
        } . BIND (?depth + 1 AS ?depth2)
    }
    """)

    results = sparql.query()

    sparql.setQuery("""
    DROP SILENT GRAPH <http://www.sparqual.org/graphs/depthNextNew>
    """)

    results = sparql.query()

    sparql.setQuery("""
    WITH <http://www.sparqual.org/graphs/depthNextNew>
    INSERT {
        ?node <http://www.sparqual.org/depth> ?depth
    } 
    USING <http://www.sparqual.org/graphs/depthNext>
    USING <http://www.sparqual.org/graphs/depth>
    WHERE {
        { 
            GRAPH <http://www.sparqual.org/graphs/depthNext> { 
                ?node ?p ?depth
            } 
        } MINUS 
        { 
            SELECT ?node WHERE { 
                GRAPH <http://www.sparqual.org/graphs/depth> {
                    ?node ?p2 ?depth2 
                } 
            }
        } .
    }
    """)

    results = sparql.query()

    sparql.setQuery("""
    WITH <http://www.sparqual.org/graphs/depth>
    INSERT {
        ?s ?p ?o
    } 
    USING <http://www.sparqual.org/graphs/depthNextNew>
    WHERE {
        GRAPH <http://www.sparqual.org/graphs/depthNextNew> { 
            ?s ?p ?o
        } 
    }
    """)

    results = sparql.query()

    sparql.setQuery("""
    DROP SILENT GRAPH <http://www.sparqual.org/graphs/global>
    """)

    results = sparql.query()

    sparql.setQuery("""
    WITH <http://www.sparqual.org/graphs/global>
    INSERT {
        <http://www.sparqual.org/global> <http://www.sparqual.org/iter> """ + str(count) + """
    }
    """)

    results = sparql.query()

    sparql.setQuery("""
        SELECT (COUNT(*) AS ?c) 
        FROM <http://www.sparqual.org/graphs/depthNextNew>
        WHERE {
            ?x ?y ?z
        }
    """)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()

    for result in results["results"]["bindings"]:
        c = result["c"]["value"]

    c = int(c)

    if c == 0:
        break
    count += 1