from SPARQLWrapper import SPARQLWrapper, POST, DIGEST, JSON

sparql = SPARQLWrapper("http://localhost:8890/sparql/")

sparql.setHTTPAuth(DIGEST)
sparql.setCredentials("dba", "dba")
sparql.setMethod(POST)

sparql.setQuery("""
DROP SILENT GRAPH <http://www.sparqual.org/graphs/degree>
""")

results = sparql.query()

sparql.setQuery("""
WITH <http://www.sparqual.org/graphs/degree>
INSERT { ?node <http://www.sparqual.org/degree> ?degree }
USING <http://example.org/patentsu>
WHERE {
  SELECT ?node (COUNT(?z) as ?degree) WHERE {
    GRAPH <http://example.org/patentsu> { ?node ?y ?z } . 
  } GROUP BY ?node
}
""")

results = sparql.query()

# 2:29.56 total