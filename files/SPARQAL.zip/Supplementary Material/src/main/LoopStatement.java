package main;

import org.apache.jena.query.Dataset;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFactory;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.sparql.resultset.ResultSetCompare;
import org.apache.jena.sparql.util.ResultSetUtils;
import org.apache.jena.tdb.TDBFactory;

public class LoopStatement implements Statement {


	public int numberOfIterations = -1;
	public String askCondition = null;
	public String fixpointCondition = null;
	public Procedure procedure;

	public LoopStatement(int numberOfIterations, Procedure procedure) {

		this.numberOfIterations = numberOfIterations;
		this.procedure = procedure;

	}

	public LoopStatement(String endCondition, Procedure procedure) {

		if(endCondition.trim().startsWith("ASK")) {
			this.askCondition = endCondition.trim();
		} else if (endCondition.trim().startsWith("FIXPOINT")) {
			this.fixpointCondition = endCondition.trim();
		}

		this.procedure = procedure;

	}

	@Override
	public void execute(Context context) {
		int count = 0;
		if (this.numberOfIterations > 0) {
			for (int i = 0; i < this.numberOfIterations; i++) {
				count++;

				procedure.execProcedure();

				if (Utilities.LOGS) {
					System.out.println("Number of Iteration: " + count);
				}
			}
		} else {
			Model dataModel;
			if (context.dataModel == null) {
				Dataset dataset = TDBFactory.createDataset(procedure.dataPath);
				dataModel = dataset.getDefaultModel();
			} else {
				dataModel = context.dataModel;
			}

			if (this.askCondition != null) {
				
				if (Utilities.LOGS) {
					System.out.println("ASK Condition");
				}

				boolean result = true;

				while (result) {
					count++;
					procedure.execProcedure();

					String askCondition = procedure.context.getQueryString(this.askCondition);
					QueryExecution qe = QueryExecutionFactory.create(askCondition, dataModel);
					result = qe.execAsk();
					qe.close();

					if (Utilities.LOGS) {
						System.out.println("Number of Iteration: " + count);
					}
				}
			} else {
				if (Utilities.LOGS) {
					System.out.println("Fixpoint");
				}
				
				String fixpoint_variable = Utilities.getVariableFixpoint(this.fixpointCondition);
				
				if (Utilities.LOGS) {
					System.out.println("Variable: " + fixpoint_variable);
				}
				
				ResultSet rs_previous = null;
				
				QueryExecution qe = null;
				while (true) {
					count++;
					procedure.execProcedure();
					
					String queryFixpoint = procedure.context.getQueryStringByVar(fixpoint_variable);
					qe = QueryExecutionFactory.create(queryFixpoint, dataModel);
					ResultSet rs_current = qe.execSelect();
					
					if (ResultSetCompare.equalsByValue(rs_previous, rs_current)) {
						break;
					}
					
					qe = QueryExecutionFactory.create(queryFixpoint, dataModel);
					
					rs_previous = qe.execSelect();
					

					if (Utilities.LOGS) {
						System.out.println("Number of Iteration: " + count);
					}
				}
				if (qe != null) {
					qe.close();
				}
				
			}

			if (context.dataModel == null) {
				dataModel.close();
			}
		}

	}

	@Override
	public String getType() {

		return "loop";

	}

}
