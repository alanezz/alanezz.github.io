package main;

import java.util.List;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.tdb.TDBLoader;

public class LCC {

	public static void main(String[] args) {
		
		Model dataModel = ModelFactory.createDefaultModel();
		dataModel.read(Utilities.path_data);

		AssignStatement edges = new AssignStatement(
				"edges", 
				"SELECT DISTINCT ?node1 ?node2 WHERE { { ?node1 ?p ?node2 } UNION { ?node2 ?p ?node1 } FILTER(?node1!=?node2) }"
				);

		AssignStatement degree = new AssignStatement(
				"degree", 
				"SELECT ?node1 (COUNT(?node2) AS ?degree) WHERE { SELECT * WHERE{ QVALUES(edges) } } GROUP BY ?node1"
				);

		/* AssignStatement coefficient = new AssignStatement(
				"coefficient", 
				"SELECT DISTINCT (?node1 AS ?node) (((COUNT(*)+?degree)/(?degree*(?degree-1)/2)) AS ?coefficient) "
				+ "WHERE { { SELECT * WHERE { QVALUES(edges) } } . "
				+ "{ SELECT ?node1 (?node2 as ?node3) WHERE { QVALUES(edges) } } . "
				+ "{ SELECT (?node1 AS ?node3) ?node2 WHERE { QVALUES(edges) } } . "
				+ "FILTER(str(?node2) < str(?node3)) . "
				+ "{ SELECT * WHERE { QVALUES(degree) } } } GROUP BY ?node1 ?degree"
				); */

		AssignStatement coefficient = new AssignStatement(
				"coefficient", 
				"SELECT DISTINCT (?node1 AS ?node) ((COUNT(?node3)+?degree) AS ?c1) (((?degree + 1)*(?degree)/2) AS ?c2) (?c1/?c2 AS ?c3) "
						+ "WHERE { { SELECT * WHERE { QVALUES(degree) } } . "
						+ "OPTIONAL { { SELECT ?node1 ?node2 WHERE { QVALUES(edges) } } ."
						+ "{ SELECT ?node1 (?node2 as ?node3) WHERE { QVALUES(edges) } } . "
						+ " { SELECT (?node1 AS ?node3) ?node2 WHERE { QVALUES(edges) } } . FILTER(str(?node2) < str(?node3)) } . "
						+ "} GROUP BY ?node1 ?degree"
				);


		OutputStatement out = new OutputStatement("coefficient");

		Procedure p = new Procedure(dataModel);		


		p.statements.add(edges);
		p.statements.add(degree);
		p.statements.add(coefficient);
		p.statements.add(out);

		long start = System.currentTimeMillis();

		p.execProcedure();
		
		long total = System.currentTimeMillis() - start;
		
		System.out.println("END - Time: " + total);



	}

}
