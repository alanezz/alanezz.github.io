package main;

public class AssignStatement implements Statement {

	public String varName;
	public String queryAssigned;
	
	public AssignStatement(String varName, String queryAssigned) {
		
		this.varName = varName;
		this.queryAssigned = queryAssigned;
		
	}
	
	@Override
	public void execute(Context context) {
		context.setQueryString(this.varName, this.queryAssigned);
	}

	@Override
	public String getType() {
		
		return "assign";
	
	}
	
}
