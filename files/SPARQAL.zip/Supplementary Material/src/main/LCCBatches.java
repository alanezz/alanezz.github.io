package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.tdb.TDBLoader;

public class LCCBatches {

	public static void main(String[] args) {
		
		Model dataModel = ModelFactory.createDefaultModel();
		dataModel.read(Utilities.path_data);
		
		String queryNodes = "SELECT ?node WHERE { { ?node ?p ?o } UNION { ?s ?p ?node } }";

		QueryExecution qe = QueryExecutionFactory.create(queryNodes, dataModel);

		ResultSet rs = qe.execSelect();

		HashSet<String> nodes = new HashSet<>();
		
		HashMap<String, String> valuesDegrees = new HashMap<>();
		HashMap<String, String> valuesEdges = new HashMap<>();
		
		int count_nodes = 0;
		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			String node = "<" + qs.get("node").toString() + ">";
			nodes.add(node);
			count_nodes++;
		}
		
		long start = System.currentTimeMillis();

		System.out.println("Here");
		for (String node : nodes) {
			String queryEdges = "SELECT ?node2 WHERE { { " + node + " ?p ?node2 } UNION { ?node2 ?p " + node + " } FILTER(" + node + "!=?node2) }";
			String valuesString = "VALUES (?node1 ?node2) { ";
			
			qe = QueryExecutionFactory.create(queryEdges, dataModel);
			rs = qe.execSelect();
			while (rs.hasNext()) {
				QuerySolution qs = rs.next();
				String node2 = "<" + qs.get("node2").toString() + ">";
				String valuesEdgesNode = "( " + node + " " + node2 + " )";
				valuesString += valuesEdgesNode;
			}
			valuesString += " }";
			valuesEdges.put(node, valuesString);
			
			String queryDegree = "SELECT ?node1 (COUNT(?node2) AS ?degree) WHERE { SELECT * WHERE{ " + valuesEdges.get(node) + " } } GROUP BY ?node1";
			
			qe = QueryExecutionFactory.create(queryDegree, dataModel);
			rs = qe.execSelect();
			if (rs.hasNext()) {
				QuerySolution qs = rs.next();
				int degree = qs.get("degree").asLiteral().getInt();
				String valuesDegree = "VALUES (?node1 ?degree) { ( " + node + " " + degree + " ) }";
				valuesDegrees.put(node, valuesDegree);
			} else {
				String valuesDegree = "VALUES (?node1 ?degree) { ( " + node + " 0 ) }";
				valuesDegrees.put(node, valuesDegree);
			}
		}
		

		for (String node : nodes) {
			System.out.println("Working with node: " + node);
			String queryString = "SELECT (?node1 AS ?node) ((COUNT(?node3)+?degree) AS ?c1) (((?degree + 1)*(?degree)/2) AS ?c2) (?c1/?c2 AS ?c3) "
					+ "WHERE { { SELECT * WHERE { " + valuesDegrees.get(node) + " } } . "
					+ "OPTIONAL { { SELECT ?node1 ?node2 WHERE { " + valuesEdges.get(node) + " } } ."
					+ "{ SELECT ?node1 (?node2 as ?node3) WHERE { " + valuesEdges.get(node) + " } } . "
					+ " { SELECT DISTINCT (?node1 AS ?node3) ?node2 WHERE { { ?node1 ?p ?node2 } UNION { ?node2 ?p ?node1 } FILTER(?node1!=?node2) } } . "
					+ "FILTER(str(?node2) < str(?node3)) } . "
					+ "} GROUP BY ?node1 ?degree";
			
			qe = QueryExecutionFactory.create(queryString, dataModel);
			rs = qe.execSelect();
			ResultSetFormatter.consume(rs);
			
		}

		
		long total = System.currentTimeMillis() - start;
		
		System.out.println("END - Time: " + total);



	}

}
