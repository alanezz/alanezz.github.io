package main;

public class OutputStatement implements Statement {

	public String varOutput;
	public String filename = null;

	public OutputStatement(String varOutput) {

		this.varOutput = varOutput;

	}

	public OutputStatement(String varOutput, String filename) {

		this.varOutput = varOutput;
		this.filename = filename;

	}

	@Override
	public void execute(Context context) {
		
		if (filename == null) {
			context.printResultSet(this.varOutput);
		}

	}

	@Override
	public String getType() {

		return "output";

	}

}
