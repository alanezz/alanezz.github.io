package main;

import java.util.ArrayList;
import java.util.List;

import org.apache.jena.query.Dataset;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.tdb.TDBFactory;

public class Procedure {

	public List<Statement> statements;
	public Context context;
	public String dataPath;
	public Model dataModel;

	public Procedure(String dataPath) {

		this.statements = new ArrayList<Statement>();
		this.dataPath = dataPath;
		this.context = new Context(dataPath);

	}

	public Procedure(String dataPath, Context context) {

		this.statements = new ArrayList<Statement>();
		this.dataPath = dataPath;
		this.context = context;

	}
	
	public Procedure(Model dataModel) {
		this.statements = new ArrayList<Statement>();
		this.dataModel = dataModel;
		this.context = new Context(dataModel);
	}
	
	public Procedure(Model dataModel, Context context) {
		this.statements = new ArrayList<Statement>();
		this.dataModel = dataModel;
		this.context = context;
	}

	public void parseProcedure(String procedureString) {
		this.statements = Parser.parseProcedure(procedureString);
	}

	public void execProcedure() {
		for(Statement st : this.statements) {
			st.execute(this.context);
		}
	}


}
