# In-database Graph Analytics with Recursive SPARQL

## About the supplemental material

In this folder you will find:

- The extended paper with the appendix containing all the proofs.
- The source code of our implementation using de VALUES approach. We recommend to import it using Eclipse and Maven (the `pom.xml` is attached).
- The data for the Wikidata experiments in `.nt` format. You have to load the data to a TDB folder to run the procedures.
- The source code of the procedures implemented with the Graph Updates approach. For using, you have to import the code using mvn with the attached `pom.xml`.
- You can download the patents dataset here: https://atlarge.ewi.tudelft.nl/graphalytics/zip/cit-Patents.zip. Then you have to unzip the file and import it with TDB.
