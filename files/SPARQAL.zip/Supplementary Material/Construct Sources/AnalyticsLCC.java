import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.jena.datatypes.RDFDatatype;
import org.apache.jena.graph.Graph;
import org.apache.jena.graph.NodeFactory;
import org.apache.jena.graph.Triple;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.DatasetFactory;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.sparql.graph.GraphFactory;
import org.apache.jena.tdb.TDBFactory;

public class AnalyticsLCC {

	public static void main(String[] args) {

		String tdb_folder = args[0];
		Dataset dataset = TDBFactory.createDataset(tdb_folder);

		// Remove graphs
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/degree");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/count");

		System.out.println("START");
		long timeStart = System.currentTimeMillis();


		String queryString = "SELECT * WHERE { ?s ?p ?o }";
		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(query, dataset);
		ResultSet rs = qe.execSelect();

		HashMap<String, HashSet<String>> nodes = new HashMap<String, HashSet<String>>();

		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			String s = qs.get("s").toString();
			String o = qs.get("o").toString();

			if (!nodes.containsKey(s)) {
				HashSet<String> hs = new HashSet<String>();
				hs.add(o);
				nodes.put(s, hs);
			} else {
				nodes.get(s).add(o);
			}

			if (!nodes.containsKey(o)) {
				HashSet<String> hs = new HashSet<String>();
				hs.add(s);
				nodes.put(o, hs);
			} else {
				nodes.get(o).add(s);
			}
		}

		Model m = ModelFactory.createDefaultModel();

		for (String key : nodes.keySet()) {
			Resource r = m.createResource(key);
			Property p = m.createProperty("http://www.sparqual.org/degree");
			int degree = nodes.get(key).size();
			r.addLiteral(p, degree * (degree - 1));

		}

		dataset = dataset.addNamedModel("http://www.sparqual.org/graphs/degree", m);

		System.out.println("Degree ready!");


		HashMap<String, Integer> triangles = new HashMap<String, Integer>();

		for (String key : nodes.keySet()) {
			HashSet<String> triangleCount = new HashSet<String>();
			for (String neighbour : nodes.get(key)) {
				for (String n_neighbour : nodes.get(neighbour)) {
					if (nodes.get(key).contains(n_neighbour)) {
						triangleCount.add(n_neighbour);
					}
				}
			}
			triangles.put(key, triangleCount.size());
		}

		Model m2 = ModelFactory.createDefaultModel();

		for (String key : triangles.keySet()) {
			Resource r = m2.createResource(key);
			Property p = m2.createProperty("http://www.sparqual.org/count");
			r.addLiteral(p, triangles.get(key));
		}

		dataset = dataset.addNamedModel("http://www.sparqual.org/graphs/count", m2);

		System.out.println("Triangles ready!");

		queryString = "SELECT ?node1 (?c1/?c2 AS ?c3) " +
				"WHERE { " +
				"GRAPH <http://www.sparqual.org/graphs/degree> { ?node1 <http://www.sparqual.org/degree> ?c1 } ." +
				"GRAPH <http://www.sparqual.org/graphs/count> { ?node1 <http://www.sparqual.org/count> ?c2 } " +
				"}" ;
		
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, dataset);

		rs = qe.execSelect();
		// System.out.println(ResultSetFormatter.asText(rs));
		ResultSetFormatter.consume(rs);

		System.out.println("C1: " + dataset.getNamedModel("http://www.sparqual.org/graphs/degree").size());
		System.out.println("C2: " + dataset.getNamedModel("http://www.sparqual.org/graphs/count").size());

		System.out.println(System.currentTimeMillis() - timeStart);
		System.out.println("END");

		dataset.close();
		qe.close();


	}

}
