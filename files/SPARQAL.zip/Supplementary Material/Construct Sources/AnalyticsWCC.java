import java.util.HashMap;
import java.util.HashSet;
import java.util.Stack;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.tdb.TDBFactory;

public class AnalyticsWCC {

	public static void main(String[] args) {

		String tdb_folder = args[0];
		Dataset dataset = TDBFactory.createDataset(tdb_folder);

		// Remove graphs
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/degree");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/wcc");

		System.out.println("START");
		long timeStart = System.currentTimeMillis();


		String queryString = "SELECT * WHERE { ?s ?p ?o }";
		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(query, dataset);
		ResultSet rs = qe.execSelect();

		HashMap<String, HashSet<String>> nodes = new HashMap<String, HashSet<String>>();
		HashMap<String, Integer> wcc = new HashMap<String, Integer>();

		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			String s = qs.get("s").toString();
			String o = qs.get("o").toString();

			if (!nodes.containsKey(s)) {
				HashSet<String> hs = new HashSet<String>();
				hs.add(o);
				nodes.put(s, hs);
			} else {
				nodes.get(s).add(o);
			}

			if (!nodes.containsKey(o)) {
				HashSet<String> hs = new HashSet<String>();
				hs.add(s);
				nodes.put(o, hs);
			} else {
				nodes.get(o).add(s);
			}
			
			if (!wcc.containsKey(s)) {
				wcc.put(s, 0);
			}
			if (!wcc.containsKey(o)) {
				wcc.put(o, 0);
			}
		}
		
		System.out.println("Neigbours Ok");
		
		int group = 1;
		for (String key : nodes.keySet()) {
			Stack<String> stack =  new Stack<String>();
			stack.push(key);
			if (wcc.get(key) == 0) {
				wcc.put(key, group);
				while(stack.size() > 0) {
					String current_node = stack.pop();
					for (String neighbour : nodes.get(current_node)) {
						if (wcc.get(neighbour) == 0) {
							wcc.put(neighbour, group);
							stack.push(neighbour);
						}
					}
				}
				group += 1;
			}
			
		}
		
		System.out.println("WCC calculated");
		
		Model m = ModelFactory.createDefaultModel();

		for (String key : wcc.keySet()) {
			Resource r = m.createResource(key);
			Property p = m.createProperty("http://www.sparqual.org/wcc");
			r.addLiteral(p, wcc.get(key));
		}

		dataset = dataset.addNamedModel("http://www.sparqual.org/graphs/wcc", m);

		queryString = "SELECT * " +
				"WHERE { " +
				"GRAPH <http://www.sparqual.org/graphs/wcc> { ?n ?p ?wcc } ." +
				"}" ;
		
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, dataset);

		rs = qe.execSelect();
		// System.out.println(ResultSetFormatter.asText(rs));
		ResultSetFormatter.consume(rs);

		System.out.println(System.currentTimeMillis() - timeStart);
		System.out.println("END");
		dataset.close();
		qe.close();


	}

}
