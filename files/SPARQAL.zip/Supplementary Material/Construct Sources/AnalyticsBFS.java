import org.apache.jena.query.Dataset;
import org.apache.jena.query.DatasetFactory;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.tdb.TDBFactory;

public class AnalyticsBFS {

	public static void main(String[] args) {

		String tdb_folder = args[0];
		Dataset dataset = TDBFactory.createDataset(tdb_folder);

		// Remove graphs
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/global");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/depth");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/depthNext");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/depthNextNew");

		Dataset datasetMem = DatasetFactory.createTxnMem();
		datasetMem = datasetMem.setDefaultModel(dataset.getDefaultModel());
		
		System.out.println("START");
		long timeStart = System.currentTimeMillis();

		String queryString = "CONSTRUCT {<http://www.sparqual.org/global> <http://www.sparqual.org/iter> ?depth} " + 
				"WHERE { VALUES (?depth) { (0) } }";
		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(query, datasetMem);
		Model m = qe.execConstruct();

		datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/global", m);

		queryString = "CONSTRUCT {?node <http://www.sparqual.org/depth> ?depth} " + 
				"WHERE { VALUES (?node ?depth) { (<http://example.org/v6009541> 0)  } }";
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, datasetMem);
		m = qe.execConstruct();

		datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/depth", m);

		queryString = "CONSTRUCT {?node <http://www.sparqual.org/depth> ?depth} " + 
				"WHERE { VALUES (?node ?depth) { (<http://example.org/v6009541> 0)  } }";
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, datasetMem);
		m = qe.execConstruct();

		datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/depthNextNew", m);

		int count = 1;
		while(true) {

			System.out.println("Iter: " + count);

			// depthNext
			queryString = "CONSTRUCT { ?neighbour <http://www.sparqual.org/depthNext> ?depth2 } " +
					"WHERE " + 
					"  {  " + 
					"	GRAPH <http://www.sparqual.org/graphs/depthNextNew> { ?node <http://www.sparqual.org/depth> ?depth} . " + 
					"  	?node ?p ?neighbour . " + 
					"	BIND (?depth + 1 AS ?depth2) " + 
					"  } ";

			query = QueryFactory.create(queryString);
			qe = QueryExecutionFactory.create(query, datasetMem);
			Model depthNext = qe.execConstruct();

			datasetMem = datasetMem.removeNamedModel("http://www.sparqual.org/graphs/depthNext");
			datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/depthNext", depthNext);

			// depthNextNew
			queryString = "CONSTRUCT { ?node <http://www.sparqual.org/depth> ?depth } " +
					"WHERE " + 
					"  {  " + 
					"	{ GRAPH <http://www.sparqual.org/graphs/depthNext> { ?node ?p ?depth} } MINUS " + 
					"	{ SELECT ?node WHERE { GRAPH <http://www.sparqual.org/graphs/depth> { ?node ?p2 ?depth2 } } } . " + 
					"  } ";

			query = QueryFactory.create(queryString);
			qe = QueryExecutionFactory.create(query, datasetMem);
			Model depthNextNew = qe.execConstruct();

			datasetMem = datasetMem.removeNamedModel("http://www.sparqual.org/graphs/depthNextNew");
			datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/depthNextNew", depthNextNew);

			// UNION of depthNextNew and depth
			queryString = "CONSTRUCT { ?s ?p ?o } " +
					"WHERE " + 
					"  {  " + 
					"	{ GRAPH <http://www.sparqual.org/graphs/depth> { ?s ?p ?o} } UNION " + 
					"	{ GRAPH <http://www.sparqual.org/graphs/depthNextNew> { ?s ?p ?o } } . " + 
					"  } ";

			query = QueryFactory.create(queryString);
			qe = QueryExecutionFactory.create(query, datasetMem);
			Model depth2 = qe.execConstruct();

			datasetMem = datasetMem.removeNamedModel("http://www.sparqual.org/graphs/depth");
			datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/depth", depth2);

			// depth value
			queryString = "CONSTRUCT { <http://www.sparqual.org/global> <http://www.sparqual.org/iter> ?depth2 } " +
					"WHERE " + 
					"  {  " + 
					"	GRAPH <http://www.sparqual.org/graphs/global> { <http://www.sparqual.org/global> <http://www.sparqual.org/iter> ?depth } " + 
					"	BIND(?depth + 1 AS ?depth2) " + 
					"  } ";

			query = QueryFactory.create(queryString);
			qe = QueryExecutionFactory.create(query, datasetMem);
			Model depthValue = qe.execConstruct();

			datasetMem = datasetMem.removeNamedModel("http://www.sparqual.org/graphs/global");
			datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/global", depthValue);

			if(depthNextNew.size() == 0) {
				break;
			}
			count++;
		}

		queryString = "SELECT * " +
				"WHERE { GRAPH <http://www.sparqual.org/graphs/depth> { ?x ?y ?z } }";
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, datasetMem);

		ResultSet rs = qe.execSelect();
		// System.out.println(ResultSetFormatter.asText(rs));
		ResultSetFormatter.consume(rs);

		System.out.println(datasetMem.getNamedModel("http://www.sparqual.org/graphs/depth").size());
		
		System.out.println(System.currentTimeMillis() - timeStart);
		System.out.println("END");

		dataset.close();
		datasetMem.close();
		qe.close();


	}

}
