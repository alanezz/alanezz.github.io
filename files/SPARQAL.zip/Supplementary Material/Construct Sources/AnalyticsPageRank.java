import java.util.Iterator;
import org.apache.jena.query.Dataset;
import org.apache.jena.query.DatasetFactory;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.tdb.TDBFactory;

public class AnalyticsPageRank {

	public static void main(String[] args) {

		String tdb_folder = args[0];
		Dataset dataset = TDBFactory.createDataset(tdb_folder);
		Dataset datasetMem = DatasetFactory.createTxnMem();

		// Remove graphs
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/nodes");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/global");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/degree");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/rank");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/rankNext");
		dataset = dataset.removeNamedModel("http://www.sparqual.org/graphs/weakRank");
		
		datasetMem = datasetMem.setDefaultModel(dataset.getDefaultModel());
		
		System.out.println("START");
		long timeStart = System.currentTimeMillis();

		String queryString = "CONSTRUCT {?node <http://www.sparqual.org/placeholderprop> <http://www.sparqual.org/placeholderobj> } " + 
				"WHERE { { SELECT ?node WHERE { ?node ?y ?z } } UNION { SELECT ?node WHERE { ?x ?y ?node }} }";
		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(query, datasetMem);
		Model m = qe.execConstruct();
		
		datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/nodes", m);
				
		
		queryString = "CONSTRUCT {<http://www.sparqual.org/global> <http://www.sparqual.org/n> ?n} " + 
				"WHERE { " + 
				"SELECT (COUNT(*) AS ?n) WHERE { " + 
				"         GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?y ?z } " + 
				"        } " + 
				"}";
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, datasetMem);
		m = qe.execConstruct();

		datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/global", m);
		
		queryString = "CONSTRUCT {?node <http://www.sparqual.org/degree> ?degree} " + 
				"		WHERE { " + 
				"			SELECT ?node (COUNT(DISTINCT ?o) as ?degree) WHERE " + 
				"					{ " + 
				"						GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?y ?z } . " + 
				"						OPTIONAL { ?node ?p ?o } " + 
				"					} GROUP BY ?node " + 
				"			}";
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, datasetMem);
		m = qe.execConstruct();

		datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/degree", m);
		
		queryString = "CONSTRUCT {?node <http://www.sparqual.org/rank> ?rank} " + 
				"		WHERE { " + 
				"			GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?p ?o } . " + 
				"			GRAPH <http://www.sparqual.org/graphs/global> { <http://www.sparqual.org/global> <http://www.sparqual.org/n> ?n } . " + 
				"			BIND (1.0/?n AS ?rank) " + 
				"			}";
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, datasetMem);
		m = qe.execConstruct();

		datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/rank", m);

		int count = 1;
		while(count < 10) {

			System.out.println("Iter: " + count);
			
			// rankNext
			queryString = "CONSTRUCT {?neighbour <http://www.sparqual.org/rankNext> ?rankNext} " + 
					"		WHERE { " + 
					"			SELECT ?neighbour (SUM(?rankEach) AS ?rankNext) WHERE { " + 
					"				GRAPH <http://www.sparqual.org/graphs/degree> { ?node <http://www.sparqual.org/degree> ?degree } . " + 
					"				GRAPH <http://www.sparqual.org/graphs/rank> { ?node <http://www.sparqual.org/rank> ?rank } . " + 
					"				?node ?p ?neighbour . " + 
					"				BIND((?rank*0.85)/?degree AS ?rankEach) " + 
					"				} GROUP BY ?neighbour " + 
					"			}";

			query = QueryFactory.create(queryString);
			qe = QueryExecutionFactory.create(query, datasetMem);
			Model rankNext = qe.execConstruct();
			
			datasetMem = datasetMem.removeNamedModel("http://www.sparqual.org/graphs/rankNext");
			datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/rankNext", rankNext);

			// weakRank
			queryString = "CONSTRUCT {<http://www.sparqual.org/global> <http://www.sparqual.org/weakRank> ?weak} " + 
					"		WHERE { " + 
					"			SELECT ((1-SUM(?rankNext))/?n AS ?weak) WHERE { " + 
					"				GRAPH <http://www.sparqual.org/graphs/rankNext> { ?neighbour <http://www.sparqual.org/rankNext> ?rankNext } . " + 
					"				GRAPH <http://www.sparqual.org/graphs/global> { <http://www.sparqual.org/global> <http://www.sparqual.org/n> ?n } " + 
					"				} GROUP BY ?n " + 
					"			}";

			query = QueryFactory.create(queryString);
			qe = QueryExecutionFactory.create(query, datasetMem);
			Model weakRank = qe.execConstruct();

			datasetMem = datasetMem.removeNamedModel("http://www.sparqual.org/graphs/weakRank");
			datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/weakRank", weakRank);

			queryString = "SELECT * WHERE { "
					+ "GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?p ?o } . "
					+ "OPTIONAL {{ SELECT ?node ?rankNext WHERE " + 
							"				{ " + 
							"					GRAPH <http://www.sparqual.org/graphs/rankNext> { ?node <http://www.sparqual.org/rankNext> ?rankNext } " + 
							"				} " + 
							"			}} . " 
					+ "GRAPH <http://www.sparqual.org/graphs/weakRank> { <http://www.sparqual.org/global> <http://www.sparqual.org/weakRank> ?weak } . "
					+ "BIND(COALESCE(?rankNext, 0) AS ?rankBound) "
					+ "}";
			
			
			// rank
			queryString = "CONSTRUCT {?node <http://www.sparqual.org/rank> ?rankBound} " + 
					"		WHERE { " + 
					"			GRAPH <http://www.sparqual.org/graphs/nodes> { ?node ?p ?o } . " + 
					"			OPTIONAL {{ SELECT ?node ?rankNext WHERE " + 
					"				{ " + 
					"					GRAPH <http://www.sparqual.org/graphs/rankNext> { ?node <http://www.sparqual.org/rankNext> ?rankNext } " + 
					"				} " + 
					"			}} . " + 
					"			GRAPH <http://www.sparqual.org/graphs/weakRank> { <http://www.sparqual.org/global> <http://www.sparqual.org/weakRank> ?weak } . " + 
					"			BIND(COALESCE(?rankNext, 0) AS ?rankBound) " + 
					"		}";

			query = QueryFactory.create(queryString);
			qe = QueryExecutionFactory.create(query, datasetMem);
			Model rank = qe.execConstruct();

			datasetMem = datasetMem.removeNamedModel("http://www.sparqual.org/graphs/rank");
			datasetMem = datasetMem.addNamedModel("http://www.sparqual.org/graphs/rank", rank);

			count++;
		}
		
		queryString = "SELECT * " +
				"WHERE { GRAPH <http://www.sparqual.org/graphs/rank> { ?x ?y ?z } }";
		query = QueryFactory.create(queryString);
		qe = QueryExecutionFactory.create(query, datasetMem);
		
		ResultSet rs = qe.execSelect();
		// System.out.println(ResultSetFormatter.asText(rs));
		ResultSetFormatter.consume(rs);
		
		System.out.println(datasetMem.getNamedModel("http://www.sparqual.org/graphs/rank").size());
		
		System.out.println(System.currentTimeMillis() - timeStart);
		System.out.println("END");

		dataset.close();
		datasetMem.close();
		qe.close();


	}

}
